//
//  main.m
//  Flip
//
//  Created by NYU User on 11/8/10.
//  edited by sha sha - added another view into the array
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, @"FlipAppDelegate");
	[pool release];
	return retVal;
}
