//
//  LittleView0.h
//  Flip
//
//  Created by NYU User on 11/8/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LittleView0: UIView {
}

@end
