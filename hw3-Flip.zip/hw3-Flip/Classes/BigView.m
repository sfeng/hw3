//
//  BigView.m
//  Flip
//
//  Created by NYU User on 11/8/10.
//  edited by sha sha - added another view into array
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "BigView.h"
#import "LittleView0.h"
#import "LittleView1.h"
#import "LittleView2.h"


@implementation BigView


- (id) initWithFrame: (CGRect) frame {
	if ((self = [super initWithFrame: frame]) != nil) {
		// Initialization code

		//Don't bother with a background color--
		//this BigView is entirely occupied by a LittleView.
		
		views = [NSArray arrayWithObjects:
			[[LittleView0 alloc] initWithFrame: self.bounds],
			[[LittleView1 alloc] initWithFrame: self.bounds],
		    [[LittleView2 alloc] initWithFrame: self.bounds],
			nil
		];
		
		[views retain];
		index = 0;	//LittleView0 is the one that's initially visible.
		[self addSubview: [views objectAtIndex: index]];
	}
	return self;
}

- (void) touchesEnded: (NSSet *) touches withEvent: (UIEvent *) event {
	
	/*
	Assume a swipe has just ended.  A more complicated program could
	distinguish between left vs. rightswipes, and perform a
	UIViewAnimationOptionTransitionFlipFromLeft or a
	UIViewAnimationOptionTransitionFlipFromRight.

	In UIViewAnimationOptionTransitionFlipFromLeft, the left edge moves
	to the right, and the right edge moves away from the user and to the
	left.
	*/
	NSUInteger newIndex;
	
	//edit rather than toggle between 1 or 0, 
	//added another view so size of array is 3 and highest index is 2
	//need if statement - newIndex is acting as a counter and resets back after it reaches max index 2
	if (newIndex < 2)
	{
		newIndex = index+1; //1 - index;	//toggle the index
	}
	else
	{	newIndex =0;
	}
	
	[UIView transitionFromView: [views objectAtIndex: index]
		toView: [views objectAtIndex: newIndex]
		duration: 2
		options:  UIViewAnimationOptionTransitionCurlUp  
		completion: NULL
	];
	
	index = newIndex;
}
	
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void) drawRect: (CGRect) rect {
    // Drawing code
}
*/

- (void) dealloc {
	for (UIView *v in views) {
		[v release];
	}
	
	[views release];
	[super dealloc];
}

@end
