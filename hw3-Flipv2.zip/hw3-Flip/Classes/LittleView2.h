//
//  LittleView2.h
//  Flip
//
//  Created by sha sha
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LittleView2: UIView {
}

@end
