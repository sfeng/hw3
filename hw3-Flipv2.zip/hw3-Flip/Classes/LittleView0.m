//
//  LittleView0.m
//  Flip
//
//  Created by NYU User on 11/8/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "LittleView0.h"


@implementation LittleView0


- (id) initWithFrame: (CGRect) frame {
	if ((self = [super initWithFrame: frame]) != nil) {
		// Initialization code
		self.backgroundColor = [UIColor redColor];
	}
	return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void) drawRect: (CGRect) rect {
	// Drawing code
	
	/*source:iphonedevelopertips.com/graphics/creating-background-patterns.html
    */
	
	UIImage* backgroundPatternImage = [UIImage imageNamed:@"grass.jpg"];
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGRect tiledRect;
	tiledRect.origin = CGPointZero;
	tiledRect.size = backgroundPatternImage.size;
	CGContextDrawTiledImage(context,tiledRect,backgroundPatternImage.CGImage);
	
	//
	UIFont *f = [UIFont systemFontOfSize: 32];
	[@"LittleView0" drawAtPoint: CGPointZero withFont: f];
	
}


- (void) dealloc {
	[super dealloc];
}

@end
