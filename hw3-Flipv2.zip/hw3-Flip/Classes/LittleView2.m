//
//  LittleView2.m
//  Flip
//
//  Created byshasha
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "LittleView2.h"


@implementation LittleView2


- (id) initWithFrame: (CGRect) frame {
	if ((self = [super initWithFrame: frame]) != nil) {
		// Initialization code
		self.backgroundColor = [UIColor whiteColor];
	}
	return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void) drawRect: (CGRect) rect {
	// Drawing code
	UIFont *f = [UIFont systemFontOfSize: 32];
	[@"LittleView2" drawAtPoint: CGPointZero withFont: f];
}


- (void) dealloc {
	[super dealloc];
}

@end
